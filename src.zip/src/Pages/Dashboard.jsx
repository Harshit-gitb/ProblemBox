import { getAuth, signOut } from "firebase/auth";
import app from "../Firebase.jsx"; // or './firebase' if it's in the same folder

const Dashboard = () => {
  return (
    <>
    Dashboard
    </>
  );
};

export default Dashboard;
