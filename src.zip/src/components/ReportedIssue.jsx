import React from 'react'

const ReportedIssue = () => {
  return (
    <div>ReportedIssue</div>
  )
}

export default ReportedIssue